$(function () {

    var step1= [
        {
            element: ".lib",
            title: "Navigation",
            content: "Select an application to browse objects",
            placement: "bottom"
        },
        {
            element: ".dm0",
            title: "Selections",
            content: "Apply bookmark across applications",
            placement: "bottom"
        },
        {
            element: "[gridid='two']",
            title: "Tile",
            content: "Object pinned will appear in Tile",
            placement: "bottom"
        }
    ];
    var step2=[{
        element: ".fav",
        title: "Set Favorite",
        content: "Click to pin object on the Main page",
        placement: "left"
    },
        {
            element: ".sidebtnL",
            title: "Global Selections",
            content: "Click to open global selections",
            placement: "right"
        },
        {
            element: ".sidebtnR",
            title: "Tag Filters",
            content: "Click to open filter objects by tag",
            placement: "left"
        },
        {
            element: ".bx-next",
            title: "Browse",
            content: "Click to switch to the next object",
            placement: "left"
        }
    ];

    function inittour(st) {
        var tour = new Tour({
            backdrop: true,
            onShown: function (tour) {
                $('.animated').removeClass('fadeIn');
                $('.animated-panel').removeClass('zoomIn');

            },
            steps: st
        });

        return tour;
    }
    // Restart the tour
    $('.logo').click(function(){
        //if($('.fav').length>0)
        //   inittour(step2).restart();
        //else
        //    inittour(step1).restart();
    });

});
