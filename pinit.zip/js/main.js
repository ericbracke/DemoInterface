'use strict';


define([
	'js/qlik',
	'jquery',
	'app',
	'punch',
	'tour',
	'help',
	'extView/main/mainCtrl',
	'extView/app/appCtrl'
], function(qlik, $, app) {
	
	return app;
});
