

define([
	'js/qlik',
	'angular',
	'head',
	'settings',
	'angularRoute',
	'bootstrap',
	'slickC',
	'slick',

], function(qlik, angular, head) {
	var reloaded=false;
	const LOCAL_SEP="%";
	qlik.setOnError(function(a) {
		console.log("Possible timeout, reloading... Code " + a.code +' message'+ a.message);
		if(reloaded==false) {
			reloaded = true;
			location.reload();
		}
	})
	$.expr[':'].regex = function(elem, index, match) {
		var matchParams = match[3].split(','),
			validLabels = /^(data|css):/,
			attr = {
				method: matchParams[0].match(validLabels) ?
					matchParams[0].split(':')[0] : 'attr',
				property: matchParams.shift().replace(validLabels,'')
			},
			regexFlags = 'ig',
			regex = new RegExp(matchParams.join('').replace(/^s+|s+$/g,''), regexFlags);
		return regex.test($(elem)[attr.method](attr.property));
	}
	function isFav(ob){
		return localStorage.getItem(ob.app+LOCAL_SEP+ob.id)!=null;
	}
	function setNavTo(elem, appId,obId,loc,$scope){
		$(elem).parent().parent().click(function(){
			if($(elem).parent().siblings( ".background" ).css("opacity")=="1"){
				$(elem).parent().siblings( ".background" ).css("opacity","0.7");
				$(elem).animate({opacity: "0"}, 1);
				var grid = $('.grid-stack').data('gridstack');
				gridItem=$(elem).parent().parent().parent();
				if(grid){
					gridItem.find(".foot").hide();
					grid.resize(gridItem, 1, 1);
					var fixY=gridItem.attr("origY");
					if(gridItem.attr("origX")==0)
						fixY=fixY+1;
					grid.move(gridItem, parseInt(gridItem.attr("origX")), parseInt(fixY));
				}
				setTimeout(function(){
					loc.path('/app/'+appId+'/ob/'+obId);
					$scope.$apply();
				},500)

			}
		})
	}
	function setEvent(el){
		$(el).attr("eventdone","ok");
		$(el).parent().siblings( ".prevent" ).children( ".zoom" ).on('click',function(ev){
			ev.stopPropagation();
			var grid = $('.grid-stack').data('gridstack');
			gridItem=$(el).parent().parent().parent();
			$(el).animate({opacity: "0"}, 1);
			if($(el).parent().siblings( ".background" ).css("opacity")=="1"){
				$(el).parent().siblings( ".prevent" ).removeClass('clickable');
				$(el).parent().siblings( ".background" ).css("opacity","0.7");
				if(grid){
					gridItem.find(".foot").hide();
					grid.resize(gridItem, 1, 1);
					var fixY=parseInt(gridItem.attr("origY"));
					if(gridItem.attr("origX")==0)
						fixY=fixY+1;
					//grid.move(gridItem, 0, 8);
					grid.move(gridItem, parseInt(gridItem.attr("origX")), parseInt(fixY));
				}
			}
			else{
				$(el).parent().siblings( ".prevent" ).addClass('clickable');
				$(el).parent().siblings( ".background" ).css("opacity","1");
				if(grid){
					gridItem.find(".foot").fadeIn("slow");
					gridItem.attr("origX",gridItem.attr("data-gs-x"));
					gridItem.attr("origY",gridItem.attr("data-gs-y"))
					grid.move(gridItem, 0, 0);
					grid.resize(gridItem, 2, 2);
				}
			}
			setTimeout(function(){
				$(el).trigger('sizeChanged');
				setTimeout(function(){$(el).animate({opacity: "1"}, 800)},30);
			},500);

		})
	}
	function setFav(appid,obid,tb){
		if(localStorage.getItem(appid+LOCAL_SEP+obid)==null){
			localStorage.setItem(appid+LOCAL_SEP+obid, obid);
			localStorage.setItem(appid, tb);
			return true;
		}
		else{
			localStorage.removeItem(appid+LOCAL_SEP+obid, obid);
			return false;
		}
	}
	function isFirstLaunch(){
		var keys = Object.keys(localStorage), i = 0;
		for (; i < keys.length; i++) {
			var stor=keys[i];
			if (stor=="first")
				return false;
		};
		i=0;
		for (; i < keys.length; i++) {
			var stor=keys[i];
			localStorage.removeItem(stor)
		}
		localStorage.setItem("first", "false");
		return true
	}
	function getSavedObjects(){
		var archive = [],keys = Object.keys(localStorage), i = 0;
		for (; i < keys.length; i++) {
			var stor = keys[i];
			if (stor.split(LOCAL_SEP).length > 1)
				archive.push({
					app: stor.split(LOCAL_SEP)[0],
					id: localStorage.getItem(stor),
					thumb: localStorage.getItem(stor.split(LOCAL_SEP)[0])
				});
		}
		return archive;
	}

	var app = angular.module('kpis', [
		'ngRoute',
		'ngAnimate',
		'slick'
	]);
	app.config(['$routeProvider', function($routeProvider,$timeout) {

		$routeProvider.
			when('/main', {
				templateUrl: 'views/main/main.html',
				controller: 'views/MainCtrl'
			}).
			when('/app/:appId/ob/:obId', {
				templateUrl: 'views/app/app.html',
				controller: 'views/AppCtrl'
			}).
			otherwise({
				redirectTo: '/main'
			});
	}]);
	var theme = require('core.utils/theme');
	app.service('helpService', [ '$q', '$rootScope', function($q, $rootScope) {
		return {
			_link:[],
			getHelp:function(link,from){
				if(link)
					this._link=link;
				var plc=function (context, source) {
					var position = $(source).position();
					if (position.left > 515) {
						return "left";
					}
					if (position.left < 515) {
						return "right";
					}
					if (position.top < 200){
						return "bottom";
					}
					return "top";
				}
				var stps= [
					{
						element: ".lib",
						title: TRANS['helpTitle1'],
						content: TRANS['helpText1'],
						placement: plc,
						path: ''
					},
					{
						element: ".dm0",
						title: TRANS['helpTitle2'],
						content: TRANS['helpText2'],
						placement: plc,
						path: ''
					},
					{
						element: "[data-gs-x='0'][data-gs-y='0']",
						title: TRANS['helpTitle3'],
						content: TRANS['helpText3'],
						placement: plc,
						path: ''
					},
					{
						element: ".frts",
						title: TRANS['helpTitle4'],
						content: TRANS['helpText4'],
						placement: "left",
						path: typeof (link)=='undefined'?'':this._link
					},
					{
						element: ".sidebtnL",
						title: TRANS['helpTitle5'],
						content: TRANS['helpText5'],
						placement: plc,
						path: ''
					},
					{
						element: ".sidebtnR",
						title: TRANS['helpTitle6'],
						content: TRANS['helpText6'],
						placement: plc,
						path: ''
					},
					{
						element: ".bx-next",
						title: TRANS['helpTitle7'],
						content: TRANS['helpText7'],
						placement: plc,
						path: ''
					},
					{
						element: ".appLink",
						title: TRANS['helpTitle8'],
						content: TRANS['helpText8'],
						placement: plc,
						path: ''
					}

				];
				var tour = new Tour({
					backdrop: true,
					onShown: function (tour) {
						$('.animated').removeClass('fadeIn');
						$('.animated-panel').removeClass('zoomIn');

					},
					steps: stps
				});
				if(from)
					tour.setCurrentStep(3)
				tour.init();
				return tour;
			}
		}
	}])
	app.service('senseService', [ '$q', '$rootScope','$timeout', function($q, $rootScope,$timeout) {

		function getThumb(myappID){
			var def=$q.defer();
			localStorage.setItem(myappID,"");
			var myapp =qlik.openApp(myappID,config);
			myapp.getAppLayout().then(function(layout){
				var pref=myapp.global.session.options.prefix!='/'?'/'+myapp.global.session.options.prefix.replace('/','').replace('/',''):'';
				localStorage.setItem(myapp.id,pref + layout.qThumbnail.qUrl);
				def.resolve();
			})
			return def.promise;
		}
		function populateDefaultStorage(){
			var allP=[];
			for (var i=0; i < DEFAULT.length; i++) {
				localStorage.setItem(DEFAULT[i],DEFAULT[i].split(LOCAL_SEP)[1]);
				if(localStorage.getItem(DEFAULT[i].split(LOCAL_SEP)[0])==null)
					allP.push(getThumb(DEFAULT[i].split(LOCAL_SEP)[0]));
			}
			return $q.all(allP);
		}
		function allStorage(){
			var tpP=$q.defer();
			if(isFirstLaunch()){
				populateDefaultStorage().then(function(s){
					location.reload();
				})
			}
			else {
				tpP.resolve(getSavedObjects());
			}
			return tpP.promise;
		}
		return {
			_hasTile:false,
			_hasSel:false,
			hasSel: function(bv){
				if (typeof(bv)=='undefined')
					return this._hasSel;
				this._hasSel=bv;
			},
			hasTile: function(bl){
				if (typeof(bl)=='undefined')
					return this._hasTile;
				this._hasTile=bl;
			},
			clearAll:function(app){
				qlik.openApp(app,config).clearAll();
			},
			selectBM:function(app,bm){
				qlik.openApp(app,config).bookmark.apply(bm);
			},
			getFavs:function(){
				return allStorage();
			},
			getBookmarks:function(apps){
				var allP=[];
				var bms=[];
				apps.forEach(function(a) {
					var ap=qlik.openApp(decodeURI(a.id),config);
					var tpP=$q.defer();
					allP.push(tpP.promise);
					ap.getList("BookmarkList", function(b) {
						b.qBookmarkList.qItems.forEach(function(itm) {
							if(itm.qMeta.description.indexOf('%')!=0)
								return;

							var title=itm.qMeta.description.replace('%',"");
							var bmFound;
							bms.forEach(function(bm){
								if(bm.title==title)
									bmFound=bm;
							})
							if(typeof(bmFound)!='undefined') {
								var valFound;
								if(typeof(bmFound.items)=='undefined')
									bmFound.items=[];
								bmFound.items.forEach(function(item){
									if(item.value==itm.qMeta.title)
										valFound=item;
								})
								if(typeof(valFound)!='undefined') {
									valFound.list.push({appId:ap.id,title:itm.qMeta.title,id:itm.qInfo.qId});
								}
								else{
									bmFound.items.push({value:itm.qMeta.title,list:[{appId:ap.id,title:itm.qMeta.title,id:itm.qInfo.qId}]})
								}

							}
							else {
								var nw=
								{
									title: title,
									items: [{
										value: itm.qMeta.title,
										list: [{appId: ap.id, title: itm.qMeta.title, id: itm.qInfo.qId}]
									}]
								};
								//nw.items.unshift({value:"CLEAR"})
								bms.push(nw);

							}
						});
						tpP.resolve(bms);
					})
				})
				return $q.all(allP);
			},
			getApps:function(){
				var qsApp = $q.defer();
				qlik.getAppList(function(b) {
					var c = [];
					b.forEach(function(a) {
						if(a.qMeta.description && a.qMeta.description.indexOf(PINIT['appKeyWord'])!=-1 )
							c.push({
								id: encodeURI(a.qDocId),
								name: a.qTitle
							})
					})
					qsApp.resolve(c);
				}, config)
				return qsApp.promise;
			},
			getMaster:function(appid){
				var qsMaster = $q.defer();
				var myapp =qlik.openApp(appid,config);
				myapp.getAppLayout().then(function(layout){
					myapp.getAppObjectList("masterobject", function(a) {
						var all=[];
						var result={};
						var pref=myapp.global.session.options.prefix!='/'?'/'+myapp.global.session.options.prefix.replace('/','').replace('/',''):'';
						result.app={thumb:pref+layout.qThumbnail.qUrl,appTitle:layout.qTitle,appDesc:layout.description,appURL:pref+"/sense/app/"+encodeURIComponent(myapp.id.replace('.qvf','')),id:myapp.id};
						var ret = [];
						var tags=[];
						a.qAppObjectList.qItems.forEach(function(a) {
							a.qMeta.tags.forEach(function(name) {
								if ($.inArray(name, tags)==-1 && name.toLowerCase()!="hidden")
									tags.push(name);
							});
							if ($.inArray("Hidden", a.qMeta.tags)==-1)
								ret.push({tags:a.qMeta.tags,id:a.qInfo.qId,footnote:a.qMeta.description,app:appid,thumb:pref+layout.qThumbnail.qUrl,appTitle:layout.qTitle,appDesc:layout.description,appURL:pref+"/sense/app/"+myapp.id})
						})
						result.curApp=myapp;
						result.objs=ret;
						result.tags=tags;
						all.push(result);
						qsMaster.resolve(result);
					})
				});

				return qsMaster.promise;
			},
			getAuthInfo:function(){
				var qAuth = $q.defer();
				var global = qlik.getGlobal(config);
				global.getAuthenticatedUser(function(reply){
					qAuth.resolve(reply.qReturn);
				});
				return qAuth.promise;
			}
		}
	}])
	app.service('themeService', [ '$q', '$rootScope', function($q, $rootScope) {

		return {

			set: function(newTheme) {

				var ret = [];
				var curBsTheme = undefined;
				$('head > link:regex(href,css/[^/]*/bootstrap\.min\.css)').each(function(index, link) {
					curBsTheme = $(link).attr('href').match(/css\/([^\/]*)\/bootstrap\.min\.css/)[1]
				})


				if(newTheme.bs != curBsTheme) {
					var bsThemeDef = $q.defer();
					ret.push(bsThemeDef.promise);

					//$('head > link:regex(href,css/[^/]*/bootstrap\.min\.css)').each(function(index, link) {
					//	link.remove();
					//})

					//head.load({test: "css/" + newTheme.bs + "/bootstrap.min.css" }, function() {
                    //
					//	bsThemeDef.resolve();
                    //
					//})
					bsThemeDef.resolve();
				}

				if(newTheme.qs != theme.name) {
					var qsThemeDef = $q.defer();
					ret.push(qsThemeDef.promise);

					theme.ThemeChanged.once(function() {
						//$('div.qvplaceholder').trigger('themeChanged');
						qsThemeDef.resolve();
					})

					theme.set(newTheme.qs);

				}

				if(ret.length == 0) {
					var fakeDef = $q.defer();
					ret.push(fakeDef.promise);
					fakeDef.resolve();
				}

				return $q.all(ret).then(function() {

				});

			}

		}

	}])
	app.controller('DefaultCtrl', function ($scope,themeService,senseService,helpService,$location,$http) {
		$scope.version=VERSION;
		$scope.home=TRANS['home'];
		$scope.library=TRANS['library'];
		$scope.helps=TRANS['help'];
		$scope.logout=TRANS['logout'];
		$scope.loaded=false;
		$scope.curBM="";
		$scope.logoutEnable=false;
		$scope.exit=function(){
			$http.delete(vp+"/qps/user");
		}
		if(window.location.port=='4848') {
			themeService.set({bs: "default", qs: "sense"}).then(function () {
				$('.layout').css('display', '')
			});
		}
		else {
			senseService.getAuthInfo().then(function (val){
				if(val.indexOf("UserDirectory=NONE; UserId=anonymous")!=0)
					$scope.logoutEnable=true;
				themeService.set({bs: "default", qs: SERVER_THEME}).then(function () {
					$('.layout').css('display', '')
				});
			});
		}

		senseService.getApps().then(function(apps){
			$scope.apps=apps;
			senseService.getBookmarks(apps).then(function(res){
				$scope.bmk=res[0];
				apps.forEach(function(a){
					senseService.clearAll(decodeURI(a.id));
				})
			})
		});
		$scope.hasSel=function(){
			return senseService.hasSel();
		}
		$scope.hasTile=function(){
			return senseService.hasTile();
		}
		$scope.clearBM=function(){
			$scope.curBM="";
			$scope.apps.forEach(function(a){
				senseService.clearAll(decodeURI(a.id));
			})
		}
		$scope.selectBM=function(allBM){
			$scope.curBM=allBM[0].title;
			allBM.forEach(function(bm){
				senseService.selectBM(bm.appId,bm.id);
			})
		}
		$scope.isMain=function(){
			return ( $location.$$path=='/main');
		}
		$scope.help=function(){
			if( $location.$$path=='/main')
				helpService.getHelp('#/app/'+($scope.apps[0].id)+ '/ob/none').restart();
			else {
				var undef
				helpService.getHelp(undef, "second").start(true);
			}
			//$('.navbar-toggle').click();

		}

	})
	app.directive("favorite", function() {
		return {
			restrict: "A",

			scope: {
				favorite : '='
			},

			link: function(scope, elem, attrs) {
				$(elem).on('qv-activate', function(event) {
					setFav(scope.favorite.app,scope.favorite.id,scope.favorite.thumb)?$(elem).removeClass("notfav"):$(elem).addClass("notfav");
				})

				scope.$watch('favorite', function(newValue, oldValue, scope) {
					if(!isFav(scope.favorite))
						$(elem).addClass("notfav");
					else
						$(elem).removeClass("notfav");
				});

			}
		}
	});
	app.directive("qvPlaceholder", function($timeout,$location,senseService) {
		return {
			restrict: "A",

			scope: {
				qvPlaceholder : '='
			},

			link: function(scope, elem, attrs) {
				$(elem).on('sizeChanged', function(event) {
					qlik.resize();
				})
				$(elem).on('qv-activate', function(event) {
					//event.preventDefault();
					event.stopPropagation()
				})
				$(elem).on('themeChanged', function(event) {
					$(elem).empty()
					qlik.openApp(scope.qvPlaceholder.app,config).getObject(elem[0],scope.qvPlaceholder.id);
				})
				$(elem).parent().siblings( ".prevent" ).click(function() {
						$(".zoom").hide();
						if (scope.qvPlaceholder && scope.qvPlaceholder.app) {
							$(this).children(".zoom").show();
						}
					}
				)
				$(elem).parent().siblings( ".prevent" ).hover(function() {
						if (scope.qvPlaceholder)
							$(".zoom").hide();
						if (scope.qvPlaceholder && scope.qvPlaceholder.app) {
							$(this).children(".zoom").show();
						}
					}, function() {
						//$(this).children(".zoom").hide();
					}
				)

				scope.$watch('qvPlaceholder', function(newValue, oldValue, scope) {
					if(scope.qvPlaceholder && scope.qvPlaceholder.app){
						$(elem).empty();
						$(elem).css("opacity","0");
						qlik.openApp(scope.qvPlaceholder.app,config).getObject(elem[0],scope.qvPlaceholder.id).then(function(ob){
							senseService.hasTile(true);
							$timeout(function(){$(elem).animate({opacity: "1"}, 500)},700)
							$(elem).siblings( ".foot" ).text(ob.layout.qMeta.description);
							if($(elem).attr("eventdone")!="ok"){
								setEvent(elem);
								setNavTo(elem,scope.qvPlaceholder.app,scope.qvPlaceholder.id,$location,scope);
							}
						},function(){
							localStorage.removeItem(scope.qvPlaceholder.app+LOCAL_SEP+scope.qvPlaceholder.id);

						})
					}else if(scope.qvPlaceholder){
						$timeout(function(){
							$(elem).parent().siblings( ".background" ).animate({opacity: "0"}, 800,function() {
								$(elem).parent().siblings( ".background" ).remove();
							});

						},500);
					}

				});

			}
		}
	});
	app.directive("qvCarousel", function($timeout,$location,senseService) {
		return {
			restrict: "A",

			scope: {
				qvCarousel : '='
			},

			link: function(scope, elem, attrs) {
				$(elem).on('sizeChanged', function(event) {
					qlik.resize();
				})
				$(elem).on('reload', function(event) {
					$(elem).empty();
					$(elem).css("opacity", "0");
					qlik.openApp(scope.qvCarousel.app, config).getObject(elem, scope.qvCarousel.id).then(function () {
						$timeout(function () {
							$(elem).animate({opacity: "1"}, 500)
						}, 700)
					})
				})
				$(elem).on('clear', function(event) {
					//$timeout(function(){$(elem).empty()});
				})
				scope.$watch('qvCarousel.load', function (attr,old) {
					if((attr==true && $(elem).children().length==0)) {
						$(elem).trigger('reload');
					}
					else if(typeof (attr)!='undefined'){
						$(elem).trigger('clear');
					}
				});
			}
		}
	});
	app.directive("search", function() {
		return {
			restrict: "A",

			scope: {
				search : '='
			},

			link: function(scope, elem, attrs) {
				$(elem).on('sizeChanged', function(event) {
					qlik.resize();
				})
				$(elem).on('themeChanged', function(event) {
					$(elem).empty()
					qlik.openApp(scope.qvPlaceholder.app,config).getObject(elem,scope.qvPlaceholder.id);
				})

				scope.$watch('search', function(newValue, oldValue, scope) {
					if(scope.search.app){
						$(elem).empty();
						var ca=qlik.openApp(scope.search.app,config);
						qlik.currApp(ca);
						qlik.currApp().getObject(elem,"CurrentSelections").then(function(){
						});
					}

				});

			}
		}
	});
	return app;
});