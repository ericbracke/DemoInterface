'use strict';
//PUT VP PREFIX HERE, IT MUST START WITH "/" OR TOTALLY EMPTY, LIKE vp="/prefvp"
var vp="/webticket";

var root = 				vp+"/resources/pinit/";
var baseU=vp+"/resources";
if(window.location.port=='4848') {
	root = "/extensions/pinit/";
	vp="";
	baseU="/resources";
}
var extRoot = 			root + 'js';
var extBowerRoot =		root + 'bower_components'

var config;

var config = {
	host: window.location.hostname,
	prefix: vp+"/",
	port: window.location.port,
	isSecure: "https:" === window.location.protocol
};

define( "client.services/grid-service", {} );
	require.config({	
		baseUrl: 					baseU,
		paths: {
			extJs : 				extRoot,
			extView : 				root + 'views',
			extLang : 				root + 'lang',
			extThemes : 			root + 'themes',
			app:					extRoot + '/app',
			punch:					extRoot + '/punch',
			tour:					extRoot + '/bootstrap-tour.min',
			help:					extRoot + '/help',
			angularRoute:			extBowerRoot + '/angular-route/angular-route-1.2.15',
			angularCssInjector: 	extBowerRoot + '/angular-css-injector/angular-css-injector',
			bootstrap:				extBowerRoot + '/bootstrap/dist/js/bootstrap.min',
			jqueryUI: 				extBowerRoot + '/jquery-ui/jquery-ui.min',
			jquerySortable: 		extBowerRoot + '/jquery-sortable/jquery.sortable',
			head: 					extBowerRoot + '/head/head',
			slickC: 				extBowerRoot + '/slick-carousel/slick/slick',
			slick: 					extBowerRoot + '/angular-slick/dist/slick',
			settings: 				root + 'settings'
		},
		
		/*
		 *  shims
		 */
		 
		shim: {
			'help': {
				deps: ['tour'],
				exports: 'help'
			},
			'slickC': {
				exports: 'slickC'
			},
			'slick': {
				deps: ['slickC'],
				exports: 'slick'
			},
			'angularCssInjector': {
				deps: ['angular'],
				exports: 'angularCssInjector'
			},
			'angularBootstrap': {
				deps: ['angular'],
				exports: 'angularBootstrap'
			},
			'jqueryUI': {
				deps: ['jquery'],
				exports: 'jqueryUI'
			},
			'jquerySortable': {
				deps: ['jquery'],
				exports: 'jquerySortable'
			},
			'head': {
				deps: ['jquery'],
				exports: 'head'
			}
		},
		priority: [
			'extJs/main',
			'angular'
		]
	})([
		'js/qlik',
		'extJs/main',
		'extJs/lodash',
		'extJs/jquery-ui.min'
		], function(qlik) {
			angular.bootstrap(document, ['qlik-angular', 'kpis']);

		}
	);
	
