const VERSION='2.0';
//ignore app thumbnails and keep default images if =true
const DEFAULT_IMG=false;
//disable thumbs behind objects on main page
const THUMB=true;
//Background Color
const BACK_COLOR="#e3e3e3";
//FONT COLOR
const FONT_COLOR="#3B4547";

//Name of the server THEME (folder name in \Program Files\Qlik\Sense\Client\themes)
const SERVER_THEME="sense";

const PINIT = {
    //Keyword searched in app description to promote it in PIN-IT
    appKeyWord: 'Pin-It',
    //Bookmark name prefix to promote it in PIN-IT
    bmkPrefix:  '%'
};

const DEFAULT=[];

//SAMPLE DEFAULT OBJECTS FOR SERVER, FORMAT IS : <APPID>%<OBJECTID>
//const DEFAULT=[   '59e9d0ae-fd98-4bb0-a10f-d4c915a260bd%wGA',
//                  'f0050171-c727-4427-828e-ba6e91be69ea%mxJdtR',
//                  'f0050171-c727-4427-828e-ba6e91be69ea%srLBhFF'];

//SAMPLE DEFAULT OBJECTS FOR DESKTOP, FORMAT IS : <APP_FULLPATH_NAME>%<OBJECTID>
//const DEFAULT=[   'C:\\Users\\aai\\Documents\\Qlik\\Sense\\Apps\\Executive Performance Mgmt.qvf%Bebjj',
//                  'C:\\Users\\aai\\Documents\\Qlik\\Sense\\Apps\\Executive Performance Mgmt.qvf%vEAJLgj'
//];



//UI translation
const TRANS= {
    //MENU
    home: 'HOME',
    library: 'LIBRARY',
    help: 'HELP',
    logout:'LOGOUT',
    //HELP
    helpTitle1  : "Navigation",
    helpText1   : "Select an application to browse objects",
    helpTitle2  : "Selections",
    helpText2   : "Apply bookmark across applications",
    helpTitle3  : "Tile",
    helpText3   : "Object pinned will appear in Tile",
    helpTitle4  : "Set Favorite",
    helpText4   : "Click to pin object on the Main page",
    helpTitle5  : "Global Selections",
    helpText5   : "Click to open global selections",
    helpTitle6  : "Tag Filters",
    helpText6   : "Click to open filter objects by tag",
    helpTitle7  : "Browse",
    helpText7   : "Click to switch to the next object",
    helpTitle8  : "Open the Application",
    helpText8   : "Click on the link to open the target Qlik Sense Application"

}
