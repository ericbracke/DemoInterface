

define([
	'js/qlik',
	'app',
	'jquery',
	'extJs/grid'
], function (qlik, app, $) {


	app.controller('views/MainCtrl', function ($scope,senseService,$timeout) {
		$scope.fontColor=FONT_COLOR;
		$scope.page="one";
		function saveGrid(id,val){
			localStorage.setItem(id,val);
		}
		function getSavedPos(id){
			if(localStorage.getItem(id)==null){
				return null;
			}
			return JSON.parse(localStorage.getItem(id))
		}
		function setPos(){
			return[{gridId:"one",clasz:"avia",x:getSavedPos("one").x,y:getSavedPos("one").y},{gridId:"two",clasz:"oil",x:getSavedPos("two").x,y:getSavedPos("two").y},
				{gridId:"three",clasz:"trans",x:getSavedPos("three").x,y:getSavedPos("three").y},
				{gridId:"four",clasz:"health",x:getSavedPos("four").x,y:getSavedPos("four").y},{gridId:"five",clasz:"powergas",x:getSavedPos("five").x,y:getSavedPos("five").y},
				{gridId:"six",clasz:"soft",x:getSavedPos("six").x,y:getSavedPos("six").y},
				{gridId:"seven",clasz:"globa",x:getSavedPos("seven").x,y:getSavedPos("seven").y},{gridId:"eight",clasz:"light",x:getSavedPos("eight").x,y:getSavedPos("eight").y},
				{gridId:"nine",clasz:"wind",x:getSavedPos("nine").x,y:getSavedPos("nine").y}];
		}
		var def=[{gridId:"one",clasz:"avia",x:"0",y:"0"},{gridId:"two",clasz:"oil",x:"1",y:"0"},{gridId:"three",clasz:"trans",x:"2",y:"0"},
			{gridId:"four",clasz:"health",x:"0",y:"1"},{gridId:"five",clasz:"powergas",x:"1",y:"1"},{gridId:"six",clasz:"soft",x:"2",y:"1"},
			{gridId:"seven",clasz:"globa",x:"0",y:"2"},{gridId:"eight",clasz:"light",x:"1",y:"2"},{gridId:"nine",clasz:"wind",x:"2",y:"2"}];

		senseService.getFavs().then(function(favs){
			if(getSavedPos("one")!=null)
				def=setPos();
			var tiles=[];
			var maxRow=3;
			for(var i=0;i<9;i++){
				var tb='default';
				if(i<favs.length){
					tiles.push({gridId:def[i].gridId,clasz:def[i].clasz,x:def[i].x,y:def[i].y,app:favs[i].app,id:favs[i].id,thumb:DEFAULT_IMG==true?tb:favs[i].thumb,pic:THUMB});
				}
				else
					tiles.push({gridId:def[i].gridId,clasz:def[i].clasz,x:def[i].x,y:def[i].y,thumb:tb,pic:THUMB});
			}
			$scope.tiles=tiles;
			senseService.hasTile(false);
			$timeout(function(){
			$('.grid-stack').gridstack({
				vertical_margin:0,
				handle:"prevent",
				height:36,
				min_width: 300,
				width:3,
				cell_height:($('body').height()-50)/maxRow,
				always_show_resize_handle: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),
				resizable: {
					handles: 'note'
				}
			});

			$(".background").css("background-color",BACK_COLOR);
			//$(".grid-stack").css("background-color",BACK_COLOR);
			$('.grid-stack').on('change', function (e, items) {
				var grid = $(".grid-stack").data("gridstack"),
					cols = [0,0,0];

				if ( $(".grid-stack-item").filter("[data-gs-width='2']").length == 0 ) {

					$(".grid-stack-item").each( function( i , v ) {
						var $v = $(v),
							col = +$v.attr("data-gs-x");

						if ( $v.attr("data-gs-width")=="2") {
							col = +$v.attr("origx");
						}

						cols[col]++;
					})
						.each( function( i , v ) {
							var $v = $(v),
								i, ilen, id, item;

							if ( +$v.attr( "data-gs-y" ) > 2 ) {
								//console.log("data-gs-y", $v.attr( "data-gs-y" ));
								for ( i = 0; i < 3; ++i ) {
									if ( cols[i] < 3 ) {
										cols[i]++;
										grid.move($v,i,cols[i]);
										break;
									}
								}
							}
						});
				}

				for(var i=0;i<items.length;i++){
					var id=$(items[i].el[0]).attr("gridId");
					saveGrid(id,'{"x":"'+ items[i].x+'","y":"'+items[i].y+'"}');
				}

			});
			$('.grid-stack').on('resizestop', function (event, ui) {
				$timeout(function(){
					//$('div.preview').trigger('sizeChanged');
					//$('div.tile').trigger('sizeChanged');
				},200)
			});
			$(window).resize(function(){
				var grid = $('.grid-stack').data('gridstack');
				if(grid)grid.cell_height(($('body').height()-50)/maxRow);
			});
		},500);
			$timeout(function(){
				//$('div.preview').trigger('sizeChanged');
				qlik.resize();
			;},500)
		})
	});

});