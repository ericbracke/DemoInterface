define([
	'js/qlik',
	'app',
	'jquery'
], function (qlik, app, $) {

	
	app.controller('views/AppCtrl',['$routeParams','senseService','helpService','$scope','$sce','$timeout','$window', function ($params,senseService,helpService,$scope,$sce,$timeout,$window) {
		function calcSize(){
			if(!$('.noMob').is(":visible") ) {
				$('.central').css("height", "calc(100% - 100px )");
				$('.filters').css('top','100px');
			}else{
				$('.central').css("height", "calc(100% - 240px )");
				$('.filters').css('top','200px');
			}
		};
		$window.onresize=function(){
			calcSize();
			$('div.slick-active').find('[max="false"]').siblings().show();
			$('div.slick-slide').find('[max]').attr("max","true");
			fixKPI()
		};
		$scope.page="two";
		$scope.loaded=false;
		$scope.ob={};
		$scope.index="";
		$scope.backColor=BACK_COLOR;
		$scope.fontColor=FONT_COLOR;
		var firstloading=true;
		var allObjects=[];
		var idx=0;
		const CACHE_SLIDE=3;
		const MIN_SIZE=50;
		var mySlick;
		responsiveSet= [
			{
				breakpoint: 3400,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 3
				}
			},
			{
				breakpoint: 1224,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				}
			},
			{
				breakpoint: 880,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
			]
		$scope.slickConfig={
			draggable: false,
			//slidesToShow: 3,
			//slidesToScroll: 1,
			infinite: false,
			dots:true,
			responsive:responsiveSet,
			event: {
				init: function (event, slick) {
					mySlick=slick;
					if(firstloading==true){
						$timeout(function(){slick.slickGoTo(idx)},100);
						firstloading=false;
                    }
					if($scope.all.length<3){
						slick.options.slidesToShow=$scope.all.length;
						slick.options.responsive[0].settings.slidesToShow=$scope.all.length;
						slick.options.responsive[1].settings.slidesToShow=$scope.all.length;
					}
					else{
						slick.options.responsive[0].settings.slidesToShow=3;
						slick.options.responsive[1].settings.slidesToShow=2;
					}
				},
				afterChange:function(event, slick, currentSlide, nextSlide){
					fixKPI();
				},
				beforeChange: function (event, slick, currentSlide, nextSlide) {
					$('div.slick-active').children().show();
					$scope.all.forEach(function(ob,id){
						if(( (id<=nextSlide) && ( (id+CACHE_SLIDE)>(nextSlide) ) ) || ((id>nextSlide) && (id-CACHE_SLIDE)<(nextSlide) ) ){
							ob.load=true;
						}
					})
					$('div.slick-slide').find('[max]').attr("max","true");
				}
			}
		};
		function fixKPI(){
			$timeout(function(){
				var elems=['.kpi-value','.kpi-title','.measure-wrapper'];
				for(var i= 0;i<elems.length;i++){
					$(elems[i]).each(function( index ) {
						$(this).css('font-size',getFontVal(this)+'px');
					});
				}
				$timeout(function() {
					var elems=['.kpi-value','.kpi-title','.measure-wrapper'];
					for(var i= 0;i<elems.length;i++){
						$(elems[i]).each(function( index ) {
							$(this).css('font-size',getFontVal(this,"")+'px');
						});
					}
				},2000)
			},1000);
		}
		function getFontVal(sel,up){
			var val=$(sel).css('font-size').replace('px','');
			if(up)
				val=val+0.1;
			else
				val=val-0.1;
			return val;
		}
		$scope.isSingle=function(){
			if(mySlick)
				return mySlick.options.slidesToShow==1;
			return true;
		};
		$scope.curTag="All";
		function getMinimized(){
			return $("div.slick-active").find('[max="false"]').length;
		};
		function getDeltaMin(){
			var mini=getMinimized();
			var delta=(mySlick.slideWidth-MIN_SIZE)/2;
			if(mini==1 && (mySlick.options.slidesToShow==2)) {
				delta = (mySlick.slideWidth - MIN_SIZE);
				$('div.slick-active').find('[max="true"]').hide();
			}
			if(mini==2 && (mySlick.options.slidesToShow==2)) {
				delta = (mySlick.slideWidth - MIN_SIZE) * 2;
				$('div.slick-active').find('[max="true"]').hide();
			}
			if(mini==1 && (mySlick.options.slidesToShow==3)) {
				delta = (mySlick.slideWidth - MIN_SIZE) / 2;
			}
			if(mini==2 && (mySlick.options.slidesToShow==3)) {
				delta = (mySlick.slideWidth - MIN_SIZE) * 2;
				$('div.slick-active').find('[max="true"]').hide();
			}
			return delta;
		}
		function getDeltaMax(){
			var mini=getMinimized();
			var delta=(mySlick.slideWidth-MIN_SIZE)/2;
			if(mini==0 && (mySlick.options.slidesToShow==2)) {
				delta = 0;
			}
			if(mini==0 && (mySlick.options.slidesToShow==3)) {
				delta = 0;
			}
			if(mini==1 && (mySlick.options.slidesToShow==3)) {
				delta = (mySlick.slideWidth - MIN_SIZE) / 2;
			}
			$('div.slick-active').find('[max="true"]').show();
			return delta;
		}
		$scope.minimize=function(ev,index){

			if($(ev.currentTarget).attr("max")=="true"){
				$(ev.currentTarget).attr("max","false");
				$('div.slick-active').find('[max="true"]').parent().animate({width:getDeltaMin(ev.currentTarget)+mySlick.slideWidth-3},500);
				$(ev.currentTarget).parent().animate({width: MIN_SIZE}, 500,function(){
					$('.preview').css("opacity", "0");
					$('.preview').animate({opacity: "1"}, 1500);
					$('.preview').trigger('sizeChanged');
					$(ev.currentTarget).siblings().hide();
				});
			}
			else{
				$(ev.currentTarget).attr("max","true");
				$('div.slick-active').find('[max="true"]').parent().animate({width:getDeltaMax()+mySlick.slideWidth-3},500,function(){
					$(ev.currentTarget).siblings().show();
					$('.preview').css("opacity", "0");
					$('.preview').animate({opacity: "1"}, 1500);
					$('.preview').trigger('sizeChanged');
				});
				//$('div.slick-active').find('[max="true"]').parent().width(getDeltaMax()+mySlick.slideWidth-3);
			}
		}
		$scope.selection=function(){
			return $(".qv-selection-toolbar").length>0;
		}
		$scope.tagged=function(name){
			$('.sideright').animate({left: '200%'}, 500);
			$('.carou').css("opacity", "0");
			$scope.curTag=name;
			if(name=="All"){
				$scope.loaded=false;
				allObjects=savedObjects;
				$scope.ob=allObjects[0];
				$scope.all=allObjects;
				$timeout(function(){$scope.loaded=true});
				$timeout(function(){$('.carou').animate({opacity: "1"}, 1000)},500);
				idx=0;
				return;
			}
				
			var filterObj=[];
				savedObjects.forEach(function(obj) {
					if ($.inArray(name, obj.tags)!=-1 && $.inArray(obj, filterObj)==-1)
					filterObj.push(obj);
				})
			allObjects=filterObj;
			$scope.loaded=false;
			$scope.all=allObjects;
			$scope.all.forEach(function(ob,id){
				if(id<3)
					ob.load=true;
			});
			$scope.ob=allObjects[0];
			$timeout(function(){$scope.loaded=true;$scope.$apply();});
			$timeout(function(){$('.carou').animate({opacity: "1"}, 1000)},500);
			idx=0;
		}
		$scope.toggleSideRight=function(){
			if(($('.sideright').position().left )>window.innerWidth){
				$('.sideright').animate({left: "70%"}, 500)
			}
			else{
				$('.sideright').animate({left: '200%'}, 500)
			}
		}
		$scope.toggleSide=function(){
			if($('.side').position().left<0){
				$('.side').animate({left: "0px"}, 500)
			}
			else{
				$('.side').animate({left: '-100%'}, 500)
			}
		}

		senseService.getMaster($params.appId).then(function(r){
			//$(".mask").css("background-color",BACK_COLOR);
			$scope.sel=$sce.trustAsResourceUrl('selectbar/index.html?app='+r.app.id);
			$scope.hasSel=false;
			$scope.tags=r.tags;
			$scope.tags.unshift("All");
			allObjects=r.objs;
			savedObjects=r.objs;
			allObjects.forEach(function(obj,id) {
				if(obj.id==$params.obId){
					idx=id;
				}
			})
			$scope.ob=allObjects[idx];
			//test
			$scope.all= allObjects;
			//fin test
			if(DEFAULT_IMG==true)
				r.app.thumb='default';
			$scope.app=r.app;
			r.curApp.getList("CurrentSelections", function(reply) {
				$scope.hasSel=reply.qSelectionObject.qSelections.length!=0;
				senseService.hasSel($scope.hasSel);
			})

			$timeout(function(){
				var undef;
				if(localStorage.getItem("tour_current_step")=="3")
					helpService.getHelp(undef,"test");
			},100)
			$timeout(function(){
				//qlik.resize();
				//$('.preview').trigger('sizeChanged');
			},5000);
			$scope.loaded=true;
			calcSize();
		});
	}]);

});